function setup(){
createCanvas(512,512);
background(50);
}

function draw(){
// set color mode
colorMode(RGB,255,255,255,1);
////////////////////////////////////////

// ufo using arc 
noStroke();
fill(255,226,41);
ellipse(128,128,50,50);

// ufo beam
beginShape();
	vertex(103,128);
	vertex(153,128);
	vertex(190,240);
	vertex(66,240);
endShape(CLOSE);

stroke(30);
fill(96,123,125);
arc(128,128,100,50,0,PI,CHORD);
fill(255,0,0)
triangle(138,145,128,130,118,145);

/////////////////////////////////////////

// main planet 
//ring back
strokeWeight(2);
stroke(255);
noFill();
ellipse(256,256,300,100);

//red planet
noStroke();
fill(255,64,41);
ellipse(256,256,150,150);

//secondary ellipse
fill(194,58,67);
ellipse(256,256,120,150);

//front ring
stroke(255);
noFill();
arc(256,256,300,100,0,PI);

/////////////////////////////////////////

//stars
noStroke();
fill(255);
ellipse(400,100,10,10);
ellipse(310,120,10,10);
ellipse(250,150,5,5);
ellipse(370,400,5,5);
ellipse(120,500,5,5);
ellipse(50,150,5,5);
ellipse(70,400,5,5);
ellipse(256,440,5,5);
ellipse(232,340,5,5);
ellipse(170,60,5,5);
ellipse(450,345,5,5);
ellipse(100,243,5,5);
ellipse(424,267,5,5);
ellipse(120,456,10,10);
ellipse(486,486,10,10);


/////////////////////////////////////
}