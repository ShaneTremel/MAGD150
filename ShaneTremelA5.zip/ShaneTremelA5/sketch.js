/* Program Assignment 5
 Shane Tremel

// Program Instructions
- To turn on computer, click the red circle
- To turn off computer, click the yellow circle and press any key
- To turn on keyboard, click on the keyboard
- To turn on mouse, click on mouse

// Known Errors
- You can turn on mouse / keyboard when computer is off

// color pallet
255,186,82  // power button on
232,147,74  // background
255,145,94  // keyboard text
232,101,74  // mouse text
255,86,82   // power button off

*/

//initialize variables
let valueR = 255;
let valueG = 86;
let valueB = 82;
let compColor = 40;
let compOn = false;
let keyText = '';
let mouseText = '';

//setup
function setup(){
	createCanvas(600,600);
	// set color mode
	colorMode(RGB,255,255,255,1);
	background(232,147,74);

	// set text attributes
	textSize(32);
	textAlign(CENTER);
}

function mouseClicked(){
	if((mouseX > 260) && (mouseX < 290) && (mouseY > 370) && (mouseY < 400)){
		valueR = 255;
		valueG = 186;
		valueB = 82;
		compColor = 255;
		compOn = true;
		if(keyIsPressed === true){
			valueG = 86;
			compColor = 40;
			compOn = false;
            keyText = '';
            mouseText = '';
		}
	}
	else if((mouseX > 460) && (mouseX < 540) && (mouseY > 450) && (mouseY < 550)){
		mouseText = 'Mouse On';
	}
	
	else if((mouseX > 150) && (mouseX < 400) && (mouseY > 480) && (mouseY < 580)){
		keyText = 'Keyboard On';
	}
	
}

//draw
function draw(){
	// draw computer setup
	fill(255);
	rect(150,480,250,100); // keyboard
	ellipse(500,500,80,100); // mouse
	stroke(0);
	strokeWeight(8);
	fill(compColor,compColor,compColor);
	rect(100,150,350,250); // monitor
	strokeWeight(2);
	fill(valueR,valueG,valueB);
	ellipse(275,385,25,25); // power button
	fill(255,145,94);
	text(keyText,275,225);
	fill(232,101,74);
	text(mouseText,275,300);
}