/* Program Assignment 3
 Shane Tremel

 Instructions:
  1) Hold the mouse to draw lines
  2) Press the left/ right arrow keys to change color, pink is a defualt color
  3) Press the shift button to erase  

*/

//initialize variables
let mx = 0; // mouse x
let my = 0; // mouse y
let px = 0; // previous mouse x
let py = 0; // previous mouse y
let fr = 0; // frame rate

//setup
function setup(){
createCanvas(1028,1028);
background(50);

// frame rate
let fr = pow(5,3);
frameRate(fr);
}

//draw
function draw(){
// set color mode
colorMode(RGB,255,255,255,1);
// set mouse variables
mx = mouseX;
my = mouseY;
px = pmouseX;
py = pmouseY;

var weight = dist(mx, my, px, py);
strokeWeight(weight);

// only draw if mouse is pressed, use key codes to change color
if(mouseIsPressed){
if(keyCode === LEFT_ARROW){
stroke(67,255,156,1);
line(mx, my, px, py);
}else if(keyCode === RIGHT_ARROW){
stroke(156,67,255,1);
line(mx, my, px, py);
}else if(keyCode === SHIFT){
stroke(50);
line(mx, my, px, py);
}else{
stroke(255,67,156,1);
line(mx, my, px, py);
}
}
}